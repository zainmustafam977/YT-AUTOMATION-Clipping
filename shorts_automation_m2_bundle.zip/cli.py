"""
CLI Interface for the YouTube Shorts Automation Platform.
Provides commands for database initialization, channel management,
video processing, status checks, RSS watch loop, dashboard server,
and WebSub subscription management.
"""

import sys
import json
import logging
from pathlib import Path
import typer
from rich.console import Console
from rich.table import Table
from rich import print as rprint

# Add root directory to pythonpath
sys.path.insert(0, str(Path(__file__).resolve().parent))

from shorts_engine.config.settings import settings
from shorts_engine.db.session import init_db, SessionLocal
from shorts_engine.db.models import Channel, SourceVideo, Clip, ClipStatus, PublishLog
from shorts_engine.services.publishing.quota import QuotaTracker
from shorts_engine.orchestration.runner import PipelineRunner

app = typer.Typer(help="YouTube Shorts Automation CLI")
channel_app = typer.Typer(help="Manage watched YouTube channels")
app.add_typer(channel_app, name="channel")
console = Console()

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


@app.command("init-db")
def cmd_init_db():
    """Initializes the database schema."""
    console.print("[bold cyan]Initializing database schema...[/bold cyan]")
    init_db()
    console.print("[bold green]Database initialized successfully![/bold green]")


@app.command("rotate-secrets")
def cmd_rotate_secrets(
    old_key: str = typer.Option(..., "--old-key", help="Current master encryption key"),
    new_key: str = typer.Option(..., "--new-key", help="New master encryption key"),
):
    """
    Bulk re-encrypts all stored channel OAuth tokens under a new master key
    in a single atomic transaction. Rolls back cleanly if any token fails.
    """
    from shorts_engine.db.security import rotate_all_channel_tokens
    init_db()
    db = SessionLocal()
    try:
        console.print("[bold cyan]Initiating bulk secret rotation across all channels...[/bold cyan]")
        count = rotate_all_channel_tokens(db, old_master_key=old_key, new_master_key=new_key)
        console.print(f"[bold green]Successfully rotated {count} stored secret(s) in a single atomic transaction![/bold green]")
        console.print("[yellow]Update MASTER_ENCRYPTION_KEY in your .env / secret manager to the new key.[/yellow]")
    except Exception as e:
        console.print(f"[bold red]Secret rotation failed! Transaction rolled back: {e}[/bold red]")
        raise typer.Exit(1)
    finally:
        db.close()


@channel_app.command("add")
def cmd_channel_add(
    channel_id: str = typer.Option(..., "--channel-id", "-c", help="YouTube Channel ID (e.g. UC...)"),
    name: str = typer.Option(..., "--name", "-n", help="Channel display name"),
    auto_publish: bool = typer.Option(False, "--auto-publish", help="Enable automatic publishing without human review"),
):
    """Adds a new YouTube channel to watch."""
    db = SessionLocal()
    try:
        existing = db.query(Channel).filter_by(youtube_channel_id=channel_id).first()
        if existing:
            console.print(f"[yellow]Channel '{name}' ({channel_id}) already exists![/yellow]")
            return

        channel = Channel(
            youtube_channel_id=channel_id,
            name=name,
            watch_enabled=True,
            human_review_required=(not auto_publish),
        )
        db.add(channel)
        db.commit()
        console.print(f"[bold green]Channel '{name}' ({channel_id}) added successfully![/bold green]")
    finally:
        db.close()


@channel_app.command("list")
def cmd_channel_list():
    """Lists all configured YouTube channels."""
    db = SessionLocal()
    try:
        channels = db.query(Channel).all()
        table = Table(title="Watched YouTube Channels")
        table.add_column("Channel ID", style="cyan")
        table.add_column("Name", style="bold white")
        table.add_column("Watch Enabled", style="green")
        table.add_column("Human Review", style="magenta")
        table.add_column("Last Seen Video", style="yellow")

        for ch in channels:
            table.add_row(
                ch.youtube_channel_id,
                ch.name,
                "YES" if ch.watch_enabled else "NO",
                "REQUIRED" if ch.human_review_required else "AUTO-PUBLISH",
                ch.last_seen_video_id or "<none>",
            )
        console.print(table)
    finally:
        db.close()


@app.command("process")
def cmd_process(
    video: str = typer.Option(..., "--video", "-v", help="YouTube video URL or Video ID"),
    dry_run: bool = typer.Option(True, "--dry-run/--live", help="Simulate upload without pushing live"),
):
    """Runs the complete shorts automation pipeline on a source video."""
    init_db()
    db = SessionLocal()
    try:
        console.print(f"[bold cyan]Launching pipeline for: {video} (dry_run={dry_run})...[/bold cyan]")
        runner = PipelineRunner(db)
        result = runner.run_pipeline_for_video(video, dry_run=dry_run)

        console.print("\n[bold green]Pipeline completed successfully![/bold green]")
        console.print(f"Title: {result['title']}")
        console.print(f"Clips Generated: {result['clips_count']}")
        for c in result.get("clips", []):
            rprint(c)
    finally:
        db.close()


@app.command("status")
def cmd_status():
    """Displays system status, pending review queue, and daily API quota."""
    init_db()
    db = SessionLocal()
    try:
        total_videos = db.query(SourceVideo).count()
        total_clips = db.query(Clip).count()
        waiting_review = db.query(Clip).filter_by(status=ClipStatus.WAITING_APPROVAL).count()
        published = db.query(Clip).filter_by(status=ClipStatus.PUBLISHED).count()
        failed = db.query(Clip).filter_by(status=ClipStatus.FAILED).count()

        tracker = QuotaTracker()
        can_pub, remaining, reason = tracker.can_publish()

        table = Table(title="YouTube Shorts Automation Status")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="bold green")

        table.add_row("Total Source Videos Ingested", str(total_videos))
        table.add_row("Total Clips Generated", str(total_clips))
        table.add_row("Clips Awaiting Human Approval", f"[yellow]{waiting_review}[/yellow]")
        table.add_row("Clips Live / Published", str(published))
        table.add_row("Failed Clips", f"[red]{failed}[/red]" if failed else "0")
        table.add_row("YouTube API Quota Remaining", f"{remaining}/{settings.DAILY_QUOTA_LIMIT} units")

        console.print(table)
    finally:
        db.close()


@app.command("watch")
def cmd_watch(
    interval: int = typer.Option(
        None, "--interval", "-i",
        help="Poll interval in minutes (default: RSS_POLL_INTERVAL_MINUTES from config)"
    ),
):
    """
    Starts the RSS fallback poll loop. Watches all enabled channels for new uploads
    and queues them for pipeline processing. Blocking — run in a tmux/screen session or as a service.
    """
    init_db()
    console.print("[bold cyan]Starting RSS watch loop...[/bold cyan]")
    console.print(f"  Interval: {interval or settings.RSS_POLL_INTERVAL_MINUTES} minutes")
    console.print(f"  Press Ctrl+C to stop.\n")

    from shorts_engine.services.detection.detector import DetectionService
    from shorts_engine.services.monitoring.alerter import PipelineAlerter

    alerter = PipelineAlerter()

    def on_new_video(channel_id: str, video_id: str):
        console.print(f"[green]Detected new video[/green] {video_id} on channel {channel_id}")
        db = SessionLocal()
        try:
            detection = DetectionService(db)
            detection.on_new_video(channel_id, video_id)
        except Exception as e:
            alerter.alert("Detection Error", str(e), level="ERROR",
                          context={"channel_id": channel_id, "video_id": video_id})
        finally:
            db.close()

    from shorts_engine.services.detection.rss_poller import RSSPollLoop
    loop = RSSPollLoop(SessionLocal, on_new_video)
    try:
        loop.run(interval_minutes=interval)
    except KeyboardInterrupt:
        console.print("\n[yellow]Watch loop stopped.[/yellow]")


@app.command("dashboard")
def cmd_dashboard(
    host: str = typer.Option(None, "--host", help="Bind host (default: DASHBOARD_HOST from config)"),
    port: int = typer.Option(None, "--port", "-p", help="Bind port (default: DASHBOARD_PORT from config)"),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload for development"),
):
    """
    Starts the operator dashboard web server.
    Access at http://<host>:<port>/ — protected by HTTP Basic Auth.
    """
    import uvicorn
    init_db()
    bind_host = host or settings.DASHBOARD_HOST
    bind_port = port or settings.DASHBOARD_PORT
    console.print(f"[bold cyan]Starting dashboard at http://{bind_host}:{bind_port}/[/bold cyan]")
    console.print(f"  Username: {settings.DASHBOARD_USERNAME}")
    console.print(f"  Password: {'*' * len(settings.DASHBOARD_PASSWORD)}\n")
    uvicorn.run(
        "shorts_engine.dashboard.app:app",
        host=bind_host,
        port=bind_port,
        reload=reload,
        log_level="info",
    )


@app.command("subscribe")
def cmd_subscribe(
    channel_id: str = typer.Option(..., "--channel-id", "-c", help="YouTube Channel ID to subscribe to"),
):
    """
    Registers a WebSub (PubSubHubbub) subscription for a channel.
    Requires WEBSUB_CALLBACK_URL to be set in config/.env.
    """
    from shorts_engine.services.detection.websub import WebSubSubscriber

    if not settings.WEBSUB_CALLBACK_URL:
        console.print("[bold red]Error: WEBSUB_CALLBACK_URL is not configured.[/bold red]")
        console.print("Set it in your .env file to a publicly reachable URL.")
        raise typer.Exit(1)

    subscriber = WebSubSubscriber()
    console.print(f"[cyan]Subscribing channel {channel_id} to WebSub hub...[/cyan]")
    success = subscriber.subscribe(channel_id)

    if success:
        console.print(f"[bold green]WebSub subscription requested for {channel_id}.[/bold green]")
        console.print(f"YouTube will verify by sending a GET to {settings.WEBSUB_CALLBACK_URL}?hub.mode=subscribe&...")
    else:
        console.print(f"[bold red]WebSub subscription failed for {channel_id}. Check logs.[/bold red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
