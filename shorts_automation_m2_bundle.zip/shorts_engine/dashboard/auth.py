"""
HTTP Basic Auth dependency for the FastAPI operator dashboard.
Credentials are loaded from DASHBOARD_USERNAME / DASHBOARD_PASSWORD in settings.
Full session-based multi-user auth is deferred to Milestone 3.
"""

import secrets
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials

from shorts_engine.config.settings import settings

security = HTTPBasic()


def verify_basic_auth(credentials: HTTPBasicCredentials = Depends(security)) -> str:
    """
    FastAPI dependency that enforces HTTP Basic Auth on all dashboard routes.
    Uses secrets.compare_digest() for timing-safe comparison.
    Returns the authenticated username on success.
    Raises HTTP 401 on failure.
    """
    correct_username = secrets.compare_digest(
        credentials.username.encode("utf-8"),
        settings.DASHBOARD_USERNAME.encode("utf-8"),
    )
    correct_password = secrets.compare_digest(
        credentials.password.encode("utf-8"),
        settings.DASHBOARD_PASSWORD.encode("utf-8"),
    )

    if not (correct_username and correct_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic realm=\"Shorts Engine Dashboard\""},
        )

    return credentials.username
