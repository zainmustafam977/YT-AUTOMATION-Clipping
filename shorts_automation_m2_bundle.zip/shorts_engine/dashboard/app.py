"""
FastAPI application factory for the Shorts Engine operator dashboard.
Mounts all route groups and configures Jinja2 templating.
"""

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from shorts_engine.dashboard.routes import status, queue, channels, websub


def create_dashboard_app() -> FastAPI:
    app = FastAPI(
        title="Shorts Engine Dashboard",
        description="Operator dashboard for YouTube Shorts Automation Platform",
        version="2.0.0",
        docs_url="/api/docs",
        redoc_url="/api/redoc",
    )

    # Mount route groups
    app.include_router(status.router, tags=["Status"])
    app.include_router(queue.router, tags=["Review Queue"])
    app.include_router(channels.router, tags=["Channels"])
    app.include_router(websub.router, tags=["WebSub"])  # No Basic Auth — HMAC secured

    return app


# Module-level app instance (used by uvicorn)
app = create_dashboard_app()
