"""Dashboard routes package."""
