"""
Status route: live pipeline summary shown on the dashboard home page.
Returns counts for videos, clips, review queue, quota usage, and recent failures.
"""

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from pathlib import Path

from shorts_engine.config.settings import settings
from shorts_engine.dashboard.auth import verify_basic_auth
from shorts_engine.db.session import SessionLocal
from shorts_engine.db.models import SourceVideo, SourceVideoStatus, Clip, ClipStatus
from shorts_engine.services.publishing.quota import QuotaTracker

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).parent.parent / "templates"))


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/", response_class=HTMLResponse, summary="Pipeline status dashboard")
def dashboard_status(
    request: Request,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    tracker = QuotaTracker()
    _, remaining, _ = tracker.can_publish()
    quota_used = settings.DAILY_QUOTA_LIMIT - remaining
    quota_pct = round((quota_used / settings.DAILY_QUOTA_LIMIT) * 100, 1)

    ctx = {
        "request": request,
        "total_videos": db.query(SourceVideo).count(),
        "in_progress": db.query(SourceVideo).filter(
            SourceVideo.status.in_([
                SourceVideoStatus.DOWNLOADING,
                SourceVideoStatus.TRANSCRIBING,
                SourceVideoStatus.ANALYZING,
                SourceVideoStatus.SEGMENTS_SELECTED,
            ])
        ).count(),
        "waiting_approval": db.query(Clip).filter_by(status=ClipStatus.WAITING_APPROVAL).count(),
        "published_today": db.query(Clip).filter_by(status=ClipStatus.PUBLISHED).count(),
        "failed_clips": db.query(Clip).filter_by(status=ClipStatus.FAILED).count(),
        "failed_videos": db.query(SourceVideo).filter_by(status=SourceVideoStatus.FAILED).count(),
        "quota_used": quota_used,
        "quota_limit": settings.DAILY_QUOTA_LIMIT,
        "quota_pct": quota_pct,
        "quota_warning": quota_pct >= (settings.QUOTA_WARNING_THRESHOLD * 100),
    }
    return templates.TemplateResponse("status.html", ctx)


@router.get("/api/status", summary="Status JSON API")
def api_status(
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    """JSON endpoint for programmatic status polling."""
    tracker = QuotaTracker()
    _, remaining, _ = tracker.can_publish()
    return {
        "total_videos": db.query(SourceVideo).count(),
        "waiting_approval": db.query(Clip).filter_by(status=ClipStatus.WAITING_APPROVAL).count(),
        "published": db.query(Clip).filter_by(status=ClipStatus.PUBLISHED).count(),
        "failed_clips": db.query(Clip).filter_by(status=ClipStatus.FAILED).count(),
        "quota_remaining": remaining,
        "quota_limit": settings.DAILY_QUOTA_LIMIT,
    }
