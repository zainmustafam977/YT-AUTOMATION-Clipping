"""
Channel management routes: list channels, toggle watch/review settings,
and manually trigger RSS poll or WebSub subscription for a channel.
"""

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from pathlib import Path

from shorts_engine.dashboard.auth import verify_basic_auth
from shorts_engine.db.session import SessionLocal
from shorts_engine.db.models import Channel

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).parent.parent / "templates"))


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/channels", response_class=HTMLResponse, summary="Channel manager")
def channel_list(
    request: Request,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    channels = db.query(Channel).order_by(Channel.created_at.asc()).all()
    return templates.TemplateResponse("channels.html", {"request": request, "channels": channels})


@router.get("/api/channels", summary="Channel list JSON API")
def api_channel_list(
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    channels = db.query(Channel).all()
    return [
        {
            "id": ch.id,
            "youtube_channel_id": ch.youtube_channel_id,
            "name": ch.name,
            "watch_enabled": ch.watch_enabled,
            "human_review_required": ch.human_review_required,
            "last_seen_video_id": ch.last_seen_video_id,
        }
        for ch in channels
    ]


@router.post("/channels/{channel_id}/toggle-watch", summary="Enable or disable channel watching")
def toggle_watch(
    channel_id: str,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    channel = db.query(Channel).filter_by(id=channel_id).first()
    if not channel:
        raise HTTPException(status_code=404, detail="Channel not found")
    channel.watch_enabled = not channel.watch_enabled
    db.commit()
    return {"channel_id": channel_id, "watch_enabled": channel.watch_enabled}


@router.post("/channels/{channel_id}/toggle-review", summary="Toggle human review requirement")
def toggle_review(
    channel_id: str,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    channel = db.query(Channel).filter_by(id=channel_id).first()
    if not channel:
        raise HTTPException(status_code=404, detail="Channel not found")
    channel.human_review_required = not channel.human_review_required
    db.commit()
    return {
        "channel_id": channel_id,
        "human_review_required": channel.human_review_required,
    }


@router.post("/channels/{channel_id}/trigger-poll", summary="Manually trigger RSS poll")
def trigger_poll(
    channel_id: str,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    """Immediately runs one RSS poll cycle for the specified channel."""
    from shorts_engine.services.detection.rss_poller import RSSPoller

    channel = db.query(Channel).filter_by(id=channel_id).first()
    if not channel:
        raise HTTPException(status_code=404, detail="Channel not found")

    poller = RSSPoller()
    new_ids = poller.poll_channel(channel, db)
    return {
        "channel_id": channel_id,
        "youtube_channel_id": channel.youtube_channel_id,
        "new_videos_detected": new_ids,
    }


@router.post("/channels/{channel_id}/subscribe-websub", summary="Register WebSub subscription")
def subscribe_websub(
    channel_id: str,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    """Registers or renews a WebSub subscription for the channel."""
    from shorts_engine.services.detection.websub import WebSubSubscriber

    channel = db.query(Channel).filter_by(id=channel_id).first()
    if not channel:
        raise HTTPException(status_code=404, detail="Channel not found")

    subscriber = WebSubSubscriber()
    success = subscriber.subscribe(channel.youtube_channel_id)
    return {
        "channel_id": channel_id,
        "youtube_channel_id": channel.youtube_channel_id,
        "subscribed": success,
    }
