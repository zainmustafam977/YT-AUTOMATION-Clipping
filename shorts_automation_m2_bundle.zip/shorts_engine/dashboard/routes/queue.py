"""
Review queue routes: approve/reject clips awaiting human review, and
dead-letter management for failed clips with retry support.
"""

from fastapi import APIRouter, Depends, HTTPException, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from pathlib import Path
from typing import Optional

from shorts_engine.config.settings import settings
from shorts_engine.dashboard.auth import verify_basic_auth
from shorts_engine.db.session import SessionLocal
from shorts_engine.db.models import Clip, ClipStatus, SourceVideo, SourceVideoStatus

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).parent.parent / "templates"))


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/queue", response_class=HTMLResponse, summary="Review queue")
def queue_list(
    request: Request,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    clips = (
        db.query(Clip)
        .filter_by(status=ClipStatus.WAITING_APPROVAL)
        .order_by(Clip.created_at.asc())
        .all()
    )
    return templates.TemplateResponse("queue.html", {"request": request, "clips": clips})


@router.post("/queue/{clip_id}/approve", summary="Approve a clip for publishing")
def approve_clip(
    clip_id: str,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    clip = db.query(Clip).filter_by(id=clip_id).first()
    if not clip:
        raise HTTPException(status_code=404, detail="Clip not found")
    if clip.status != ClipStatus.WAITING_APPROVAL:
        raise HTTPException(
            status_code=409,
            detail=f"Clip is in status {clip.status.value}, not WAITING_APPROVAL",
        )
    clip.status = ClipStatus.APPROVED
    db.commit()
    return {"clip_id": clip_id, "new_status": ClipStatus.APPROVED.value}


@router.post("/queue/{clip_id}/reject", summary="Reject a clip")
def reject_clip(
    clip_id: str,
    reason: Optional[str] = Form(default=None),
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    clip = db.query(Clip).filter_by(id=clip_id).first()
    if not clip:
        raise HTTPException(status_code=404, detail="Clip not found")
    if clip.status != ClipStatus.WAITING_APPROVAL:
        raise HTTPException(
            status_code=409,
            detail=f"Clip is in status {clip.status.value}, not WAITING_APPROVAL",
        )
    clip.status = ClipStatus.REJECTED
    if reason:
        import json
        existing = json.loads(clip.quality_check_result or "{}")
        existing["rejection_reason"] = reason
        clip.quality_check_result = json.dumps(existing)
    db.commit()
    return {"clip_id": clip_id, "new_status": ClipStatus.REJECTED.value, "reason": reason}


@router.get("/dead-letter", response_class=HTMLResponse, summary="Dead-letter queue")
def dead_letter_list(
    request: Request,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    failed_clips = (
        db.query(Clip)
        .filter_by(status=ClipStatus.FAILED)
        .order_by(Clip.updated_at.desc())
        .all()
    )
    failed_videos = (
        db.query(SourceVideo)
        .filter_by(status=SourceVideoStatus.FAILED)
        .order_by(SourceVideo.updated_at.desc())
        .all()
    )
    return templates.TemplateResponse(
        "dead_letter.html",
        {"request": request, "failed_clips": failed_clips, "failed_videos": failed_videos},
    )


@router.post("/dead-letter/clip/{clip_id}/retry", summary="Retry a failed clip")
def retry_failed_clip(
    clip_id: str,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    clip = db.query(Clip).filter_by(id=clip_id).first()
    if not clip:
        raise HTTPException(status_code=404, detail="Clip not found")
    if clip.status != ClipStatus.FAILED:
        raise HTTPException(status_code=409, detail="Clip is not in FAILED status")
    if clip.retry_count >= settings.MAX_RETRY_COUNT:
        raise HTTPException(
            status_code=422,
            detail=f"Clip has exhausted max retries ({settings.MAX_RETRY_COUNT}). Manual intervention required.",
        )
    clip.status = ClipStatus.RENDERING
    clip.retry_count += 1
    db.commit()
    return {
        "clip_id": clip_id,
        "new_status": ClipStatus.RENDERING.value,
        "retry_count": clip.retry_count,
        "max_retries": settings.MAX_RETRY_COUNT,
    }


@router.post("/dead-letter/video/{video_id}/retry", summary="Retry a failed source video")
def retry_failed_video(
    video_id: str,
    db: Session = Depends(get_db),
    _: str = Depends(verify_basic_auth),
):
    video = db.query(SourceVideo).filter_by(id=video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    if video.status != SourceVideoStatus.FAILED:
        raise HTTPException(status_code=409, detail="Video is not in FAILED status")
    if video.retry_count >= settings.MAX_RETRY_COUNT:
        raise HTTPException(
            status_code=422,
            detail=f"Video has exhausted max retries ({settings.MAX_RETRY_COUNT}). Manual intervention required.",
        )
    video.status = SourceVideoStatus.DETECTED
    video.retry_count += 1
    video.error_message = None
    db.commit()
    return {
        "video_id": video_id,
        "new_status": SourceVideoStatus.DETECTED.value,
        "retry_count": video.retry_count,
        "max_retries": settings.MAX_RETRY_COUNT,
    }
