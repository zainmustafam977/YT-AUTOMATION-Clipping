"""
Transcription engine wrapping faster-whisper with automatic GPU/CPU auto-detection
and word-level timestamp alignment.
"""

import logging
from pathlib import Path
from typing import Optional
import torch
from shorts_engine.config.settings import settings
from shorts_engine.services.transcription.formatter import WordSegment, FormattedTranscript
from shorts_engine.services.transcription.aligner import ForcedAligner

logger = logging.getLogger(__name__)


class TranscriptionService:
    def __init__(
        self,
        model_size: str = "base",
        device: Optional[str] = None,
        compute_type: Optional[str] = None,
    ):
        self.model_size = model_size
        
        # Auto-detect hardware
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        if compute_type is None:
            self.compute_type = "float16" if self.device == "cuda" else "int8"
        else:
            self.compute_type = compute_type

        logger.info(
            "Initializing TranscriptionService (model=%s, device=%s, compute_type=%s)",
            self.model_size,
            self.device,
            self.compute_type,
        )
        self._model = None
        self.aligner = ForcedAligner(device=self.device)

    @property
    def model(self):
        if self._model is None:
            try:
                from faster_whisper import WhisperModel
                self._model = WhisperModel(
                    self.model_size,
                    device=self.device,
                    compute_type=self.compute_type,
                    download_root=str(settings.MODELS_DIR / "whisper"),
                )
            except Exception as e:
                logger.error("Failed to load faster-whisper model: %s", str(e))
                raise RuntimeError(f"Could not load faster-whisper model: {e}")
        return self._model

    def transcribe(self, audio_path: Path, language: Optional[str] = None) -> FormattedTranscript:
        """
        Transcribes the given audio file and produces word-level timestamped segments.
        Applies forced alignment to ensure +/-50ms precision.
        """
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio file not found: {audio_path}")

        logger.info("Transcribing %s...", audio_path.name)
        segments, info = self.model.transcribe(
            str(audio_path),
            language=language,
            word_timestamps=True,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=400),
        )

        raw_words = []
        full_text_parts = []
        for segment in segments:
            full_text_parts.append(segment.text.strip())
            if segment.words:
                for w in segment.words:
                    raw_words.append(
                        WordSegment(
                            word=w.word.strip(),
                            start=w.start,
                            end=w.end,
                            probability=getattr(w, "probability", 1.0),
                        )
                    )

        # Apply forced alignment pass to eliminate cross-attention drift
        aligned_words = self.aligner.align(audio_path, raw_words)

        return FormattedTranscript(
            words=aligned_words,
            language=info.language or "en",
            full_text=" ".join(full_text_parts),
        )
