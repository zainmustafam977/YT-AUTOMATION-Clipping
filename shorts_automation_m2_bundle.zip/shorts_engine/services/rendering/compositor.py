"""
Rendering Service: FFmpeg compositor that crops to 9:16 portrait, burns in karaoke ASS subtitles,
normalizes audio to EBU R128 standards, ducks background audio, and validates the final MP4.
"""

import os
import json
import logging
import subprocess
from pathlib import Path
from typing import Dict, Any, Optional, List
from shorts_engine.config.settings import settings
from shorts_engine.services.reframing.cropper import CropPlan

logger = logging.getLogger(__name__)


def escape_ffmpeg_filter_path(path: Path) -> str:
    """
    Escapes a filesystem path for inclusion in FFmpeg filter graph parameters.
    Converts backslashes to forward slashes and escapes colons for Windows paths.
    """
    path_str = str(path.resolve()).replace("\\", "/")
    # Escape colon (e.g. D:/ -> D\\:/)
    path_str = path_str.replace(":", "\\:")
    return path_str


class RenderValidationResult:
    def __init__(
        self,
        is_valid: bool,
        duration_sec: float,
        width: int,
        height: int,
        has_audio: bool,
        file_size_bytes: int,
        error: Optional[str] = None,
    ):
        self.is_valid = is_valid
        self.duration_sec = duration_sec
        self.width = width
        self.height = height
        self.has_audio = has_audio
        self.file_size_bytes = file_size_bytes
        self.error = error

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_valid": self.is_valid,
            "duration_sec": round(self.duration_sec, 2),
            "width": self.width,
            "height": self.height,
            "has_audio": self.has_audio,
            "file_size_bytes": self.file_size_bytes,
            "error": self.error,
        }

    def __repr__(self) -> str:
        return (
            f"<RenderValidationResult valid={self.is_valid} "
            f"res={self.width}x{self.height} dur={self.duration_sec:.1f}s>"
        )


class VideoCompositor:
    def __init__(self, output_dir: Optional[Path] = None):
        self.output_dir = output_dir or settings.OUTPUT_DIR
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def render_short(
        self,
        source_video_path: Path,
        start_ms: int,
        end_ms: int,
        crop_plan: CropPlan,
        subtitle_ass_path: Optional[Path],
        output_filename: str,
        normalize_audio: bool = True,
    ) -> Path:
        """
        Renders a finished 9:16 portrait Short video using FFmpeg.
        """
        output_path = self.output_dir / output_filename
        start_sec = max(0.0, start_ms / 1000.0)
        duration_sec = max(1.0, (end_ms - start_ms) / 1000.0)

        # Build video filter chain
        v_filters = []
        # 1. 9:16 crop and scale
        v_filters.append(crop_plan.to_ffmpeg_filter())
        # 2. Burn in ASS subtitles if provided
        if subtitle_ass_path and subtitle_ass_path.exists():
            escaped_sub = escape_ffmpeg_filter_path(subtitle_ass_path)
            v_filters.append(f"ass='{escaped_sub}'")

        video_filter_arg = ",".join(v_filters)

        # Build audio filter chain (EBU R128 Loudness Normalization)
        a_filters = []
        if normalize_audio:
            a_filters.append(f"loudnorm=I={settings.TARGET_LUFS}:TP={settings.TRUE_PEAK_DBFS}:LRA=11")
        audio_filter_arg = ",".join(a_filters) if a_filters else "anull"

        cmd = [
            "ffmpeg",
            "-y",
            "-ss", f"{start_sec:.3f}",
            "-i", str(source_video_path),
            "-t", f"{duration_sec:.3f}",
            "-vf", video_filter_arg,
            "-af", audio_filter_arg,
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "22",
            "-c:a", "aac",
            "-b:a", "192k",
            "-pix_fmt", "yuv420p",
            "-movflags", "+faststart",
            str(output_path),
        ]

        logger.info("Executing FFmpeg render for %s...", output_filename)
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode != 0:
            logger.error("FFmpeg render failed:\n%s", result.stderr)
            raise RuntimeError(f"FFmpeg render failed: {result.stderr[-400:]}")

        logger.info("Render completed successfully: %s", output_path)
        return output_path

    def validate_render(self, video_path: Path) -> RenderValidationResult:
        """
        Validates the rendered video file using ffprobe.
        """
        if not video_path.exists() or video_path.stat().st_size == 0:
            return RenderValidationResult(
                is_valid=False,
                duration_sec=0.0,
                width=0,
                height=0,
                has_audio=False,
                file_size_bytes=0,
                error="File does not exist or is 0 bytes",
            )

        cmd = [
            "ffprobe",
            "-v", "quiet",
            "-print_format", "json",
            "-show_format",
            "-show_streams",
            str(video_path),
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode != 0:
            return RenderValidationResult(
                is_valid=False,
                duration_sec=0.0,
                width=0,
                height=0,
                has_audio=False,
                file_size_bytes=video_path.stat().st_size,
                error=f"ffprobe failed: {result.stderr}",
            )

        try:
            info = json.loads(result.stdout)
            format_info = info.get("format", {})
            duration = float(format_info.get("duration", 0.0))
            
            width = 0
            height = 0
            has_audio = False

            for stream in info.get("streams", []):
                if stream.get("codec_type") == "video" and width == 0:
                    width = int(stream.get("width", 0))
                    height = int(stream.get("height", 0))
                elif stream.get("codec_type") == "audio":
                    has_audio = True

            # Verify 9:16 resolution and audio
            is_valid = (width == settings.TARGET_WIDTH and height == settings.TARGET_HEIGHT and has_audio and duration > 0.0)
            err = None if is_valid else f"Failed checks: width={width}, height={height}, has_audio={has_audio}"

            return RenderValidationResult(
                is_valid=is_valid,
                duration_sec=duration,
                width=width,
                height=height,
                has_audio=has_audio,
                file_size_bytes=video_path.stat().st_size,
                error=err,
            )
        except Exception as e:
            return RenderValidationResult(
                is_valid=False,
                duration_sec=0.0,
                width=0,
                height=0,
                has_audio=False,
                file_size_bytes=video_path.stat().st_size,
                error=f"JSON parsing error: {e}",
            )
