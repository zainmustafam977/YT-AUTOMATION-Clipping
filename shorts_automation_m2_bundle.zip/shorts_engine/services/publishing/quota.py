"""
YouTube Data API Quota Tracker: protects against daily quota exhaustion (10k units/day limit).
Each video insert consumes ~1,600 units. Queues jobs when threshold is reached.
"""

import json
import logging
from datetime import datetime, date
from pathlib import Path
from typing import Dict, Any, Tuple, Optional
from shorts_engine.config.settings import settings

logger = logging.getLogger(__name__)

UPLOAD_COST_UNITS = 1600


class QuotaTracker:
    def __init__(self, state_file: Optional[Path] = None):
        self.state_file = state_file or settings.STORAGE_DIR / "quota_state.json"
        self.daily_limit = settings.DAILY_QUOTA_LIMIT

    def _load_state(self) -> Dict[str, Any]:
        today_str = date.today().isoformat()
        if self.state_file.exists():
            try:
                data = json.loads(self.state_file.read_text(encoding="utf-8"))
                if data.get("date") == today_str:
                    return data
            except Exception:
                pass
        return {"date": today_str, "used_units": 0}

    def _save_state(self, state: Dict[str, Any]) -> None:
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self.state_file.write_text(json.dumps(state, indent=2), encoding="utf-8")

    def can_publish(self) -> Tuple[bool, int, str]:
        """
        Returns (can_publish: bool, remaining_units: int, reason: str).
        """
        state = self._load_state()
        used = state.get("used_units", 0)
        remaining = max(0, self.daily_limit - used)

        if remaining < UPLOAD_COST_UNITS:
            msg = (
                f"Daily YouTube quota exhausted! Used: {used}/{self.daily_limit} units. "
                f"Required: {UPLOAD_COST_UNITS}. Queuing for next quota reset."
            )
            logger.warning(msg)
            return False, remaining, msg

        usage_ratio = used / float(self.daily_limit)
        if usage_ratio >= settings.QUOTA_WARNING_THRESHOLD:
            logger.warning("YouTube quota usage alert: %d%% used (%d/%d)", int(usage_ratio * 100), used, self.daily_limit)

        return True, remaining, "Quota available"

    def record_publish(self, cost: int = UPLOAD_COST_UNITS) -> int:
        """Records consumption of quota units."""
        state = self._load_state()
        state["used_units"] = state.get("used_units", 0) + cost
        self._save_state(state)
        logger.info("Recorded %d quota units. Total used today: %d/%d", cost, state["used_units"], self.daily_limit)
        return state["used_units"]
