"""
Semantic Quality Verifier: evaluates candidate Short text, hook, and narrative resolution
to verify standalone autonomy, zero missing context, and clean hook payoff.
"""

import os
import json
import logging
from typing import Dict, Any, Tuple, Optional
from pydantic import BaseModel, Field
from shorts_engine.config.settings import settings

logger = logging.getLogger(__name__)


class SemanticVerificationSchema(BaseModel):
    is_autonomous: bool = Field(description="True if the clip makes 100% sense without having seen the full video")
    has_unresolved_pronouns: bool = Field(description="True if clip references unmentioned things like 'as I said earlier'")
    delivers_payoff: bool = Field(description="True if the clip provides a punchline, conclusion, or resolution to the hook")
    pass_decision: bool = Field(description="Overall pass/fail recommendation")
    critique_reason: str = Field(description="Detailed reason for approval or rejection")


class SemanticVerifier:
    def __init__(self, model_name: Optional[str] = None, api_key: Optional[str] = None):
        self.model_name = model_name or settings.LLM_MODEL_NAME
        self.api_key = api_key or settings.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY")
        self._client = None

    @property
    def client(self):
        if self._client is None and self.api_key:
            try:
                from google import genai
                self._client = genai.Client(api_key=self.api_key)
            except Exception as e:
                logger.warning("Could not initialize google.genai: %s", str(e))
        return self._client

    def verify_segment(
        self,
        segment_text: str,
        hook_text: str,
        payoff_text: str,
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Evaluates the clip transcript for autonomy, dangling references, and payoff delivery.
        """
        if not segment_text:
            return False, {"error": "Segment text is empty"}

        if self.client:
            try:
                prompt = f"""Evaluate this YouTube Short candidate for standalone autonomy and narrative completion.

HOOK: {hook_text}
PAYOFF: {payoff_text}
FULL CLIP TRANSCRIPT:
"{segment_text}"

CRITERIA:
1. Is it 100% autonomous without needing prior context?
2. Does it contain dangling references like 'as we said before' or 'in the next video'?
3. Does it deliver on the hook with a satisfying payoff?
"""
                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=prompt,
                    config=dict(
                        response_mime_type="application/json",
                        response_schema=SemanticVerificationSchema,
                        temperature=0.1,
                    ),
                )
                parsed = json.loads(response.text)
                schema_res = SemanticVerificationSchema.model_validate(parsed)
                passed = schema_res.pass_decision and schema_res.is_autonomous and not schema_res.has_unresolved_pronouns
                return passed, schema_res.model_dump()
            except Exception as e:
                logger.warning("LLM semantic check failed: %s. Using rule-based fallback.", str(e))

        # Rule-based fallback
        forbidden_phrases = ["as i said before", "in the previous video", "like we mentioned earlier", "stay tuned for part 2"]
        has_forbidden = any(phrase in segment_text.lower() for phrase in forbidden_phrases)
        word_count = len(segment_text.split())
        passed = (not has_forbidden) and (word_count >= 20)

        details = {
            "pass_decision": passed,
            "is_autonomous": not has_forbidden,
            "has_unresolved_pronouns": has_forbidden,
            "delivers_payoff": True,
            "critique_reason": "Passed automated heuristic check." if passed else "Detected dangling reference or insufficient length.",
        }
        return passed, details
