"""
Quality Gate Review Queue & State Machine: orchestrates technical, multimodal,
and semantic verifiers to transition clips to WAITING_APPROVAL, APPROVED, or REJECTED.
"""

import json
import logging
from pathlib import Path
from typing import Dict, Any, Tuple
from shorts_engine.db.models import Clip, ClipStatus
from shorts_engine.services.quality_gate.technical_check import TechnicalVerifier
from shorts_engine.services.quality_gate.render_inspector import RenderInspector
from shorts_engine.services.quality_gate.semantic_check import SemanticVerifier

logger = logging.getLogger(__name__)


class QualityGateManager:
    def __init__(self):
        self.technical_verifier = TechnicalVerifier()
        self.render_inspector = RenderInspector()
        self.semantic_verifier = SemanticVerifier()

    def evaluate_clip(
        self,
        rendered_video_path: Path,
        segment_text: str,
        hook_text: str,
        payoff_text: str,
        human_review_required: bool = True,
    ) -> Tuple[ClipStatus, Dict[str, Any]]:
        """
        Runs the complete quality gate pipeline:
        1. Technical check (aspect ratio, duration, streams)
        2. Multimodal post-render inspection (subject safe framing, caption UI collision)
        3. Semantic check (autonomy, dangling references, hook resolution)
        
        Returns (new_status, evaluation_report).
        """
        logger.info("Running Quality Gate on %s...", rendered_video_path.name)
        report: Dict[str, Any] = {}

        # 1. Technical verification
        tech_pass, tech_details = self.technical_verifier.verify(rendered_video_path)
        report["technical_check"] = tech_details
        if not tech_pass:
            logger.warning("Clip %s failed technical check", rendered_video_path.name)
            return ClipStatus.REJECTED, report

        # 2. Multimodal post-render inspection
        render_pass, render_details = self.render_inspector.inspect_render(rendered_video_path)
        report["render_inspection"] = render_details
        if not render_pass:
            logger.warning("Clip %s failed render inspection", rendered_video_path.name)
            return ClipStatus.REJECTED, report

        # 3. Semantic check
        sem_pass, sem_details = self.semantic_verifier.verify_segment(
            segment_text=segment_text,
            hook_text=hook_text,
            payoff_text=payoff_text,
        )
        report["semantic_check"] = sem_details
        if not sem_pass:
            logger.warning("Clip %s failed semantic check", rendered_video_path.name)
            return ClipStatus.REJECTED, report

        # All automated checks passed!
        if human_review_required:
            logger.info("Clip %s passed quality gate. Queued for WAITING_APPROVAL.", rendered_video_path.name)
            return ClipStatus.WAITING_APPROVAL, report
        else:
            logger.info("Clip %s passed quality gate. Auto-promoted to APPROVED.", rendered_video_path.name)
            return ClipStatus.APPROVED, report
