"""
Prompts and schemas for AI Clip Selection (Generator + Critic passes).
"""

from typing import List, Optional
from pydantic import BaseModel, Field


class CandidateSegmentSchema(BaseModel):
    start_sec: float = Field(description="Approximate start time in seconds")
    end_sec: float = Field(description="Approximate end time in seconds")
    hook_text: str = Field(description="The opening statement/hook within the first 3 seconds")
    payoff_text: str = Field(description="The punchline, key takeaway, or resolution")
    score: float = Field(ge=0.0, le=1.0, description="Quality and viral potential score (0.0 to 1.0)")
    reason: str = Field(description="Detailed editorial justification for why this segment works as a standalone Short")
    suggested_title: str = Field(description="High-CTR YouTube Shorts title (under 60 characters)")
    suggested_description: str = Field(description="Short description with 3-5 relevant hashtags")
    suggested_tags: List[str] = Field(description="List of 3-7 tags (e.g. ['#shorts', '#tech'])")


class CandidateSegmentsResponse(BaseModel):
    candidates: List[CandidateSegmentSchema] = Field(
        description="Ranked list of standalone Short candidates extracted from the transcript"
    )


GENERATOR_CRITIC_PROMPT = """You are an elite short-form video editor and YouTube algorithm strategist.
Your task is to analyze a timestamped transcript of a long-form video and extract the top {min_count} to {max_count} most compelling, high-retention vertical Short clips.

EVALUATION RUBRIC:
1. HOOK STRENGTH (0-3s): Does the clip immediately capture attention with a provocative question, shocking claim, counter-intuitive insight, or high curiosity gap?
2. STANDALONE AUTONOMY: Can a viewer who has never seen the long-form video understand the entire context without confusion? NO unresolved pronouns ("as I mentioned earlier", "like we saw before").
3. PAYOFF & RESOLUTION: Does the clip deliver on the premise established by the hook? Does it provide a clean punchline, conclusion, or takeaway?
4. DURATION FIT: Strict target between {min_dur}s and {max_dur}s. Never stop mid-thought.

TRANSCRIPT WITH TIMESTAMPS:
{transcript_text}

Extract {min_count} to {max_count} candidate clips strictly conforming to the requested JSON schema. Rank them by overall quality score.
"""
