"""
Speech boundary snapping: adjusts candidate cut points to natural silence gaps
and word boundaries to guarantee cuts never slice words or breath pauses.
"""

import logging
from typing import List, Tuple
from shorts_engine.config.settings import settings
from shorts_engine.services.transcription.formatter import FormattedTranscript, WordSegment

logger = logging.getLogger(__name__)


class BoundarySnapper:
    """
    Snaps proposed start_ms and end_ms to the nearest silence or word boundary.
    Enforces TARGET_DURATION_MIN_SEC and TARGET_DURATION_MAX_SEC from settings.
    """

    def __init__(
        self,
        min_duration_sec: float = settings.TARGET_DURATION_MIN_SEC,
        max_duration_sec: float = settings.TARGET_DURATION_MAX_SEC,
    ):
        self.min_duration_sec = min_duration_sec
        self.max_duration_sec = max_duration_sec

    def snap_boundaries(
        self,
        raw_start_sec: float,
        raw_end_sec: float,
        transcript: FormattedTranscript,
    ) -> Tuple[int, int, str]:
        """
        Takes raw start and end in seconds, finds optimal word boundaries,
        and returns (start_ms, end_ms, segment_text).
        """
        words = transcript.words
        if not words:
            start_ms = int(raw_start_sec * 1000)
            end_ms = int(raw_end_sec * 1000)
            return start_ms, end_ms, ""

        # Find closest starting word
        start_idx = 0
        min_start_diff = float("inf")
        for idx, w in enumerate(words):
            diff = abs(w.start - raw_start_sec)
            if diff < min_start_diff:
                min_start_diff = diff
                start_idx = idx

        # Look for a sentence start or pause preceding start_idx within 2 seconds
        best_start_idx = start_idx
        for idx in range(max(0, start_idx - 5), start_idx + 1):
            if idx > 0 and (words[idx].start - words[idx - 1].end) >= 0.25:
                best_start_idx = idx
                break
            if words[idx].word.endswith((".", "!", "?")) and idx + 1 < len(words):
                best_start_idx = idx + 1
                break

        actual_start_sec = words[best_start_idx].start

        # Target end: aim for proposed end, but snap to punctuation or silence
        target_end_sec = min(
            raw_end_sec,
            actual_start_sec + self.max_duration_sec
        )

        end_idx = best_start_idx
        min_end_diff = float("inf")
        for idx in range(best_start_idx, len(words)):
            diff = abs(words[idx].end - target_end_sec)
            if diff < min_end_diff:
                min_end_diff = diff
                end_idx = idx

        # Find all candidate end words that have sentence punctuation (. ! ?)
        # or natural silence gap within [min_duration_sec, max_duration_sec]
        best_candidate_idx = None
        min_target_distance = float("inf")

        for idx in range(best_start_idx, len(words)):
            dur = words[idx].end - actual_start_sec
            if dur < self.min_duration_sec:
                continue
            if dur > self.max_duration_sec:
                break

            # Punctuation or pause
            has_punct = words[idx].word.endswith((".", "!", "?"))
            has_pause = (idx + 1 < len(words)) and ((words[idx + 1].start - words[idx].end) >= 0.25)
            
            if has_punct or has_pause:
                dist = abs(words[idx].end - target_end_sec)
                # Prefer punctuation/pause
                if dist < min_target_distance:
                    min_target_distance = dist
                    best_candidate_idx = idx

        if best_candidate_idx is not None:
            best_end_idx = best_candidate_idx
        else:
            # Fallback to closest word within bounds
            best_end_idx = best_start_idx
            closest_dist = float("inf")
            for idx in range(best_start_idx, len(words)):
                dur = words[idx].end - actual_start_sec
                if self.min_duration_sec <= dur <= self.max_duration_sec:
                    dist = abs(words[idx].end - target_end_sec)
                    if dist < closest_dist:
                        closest_dist = dist
                        best_end_idx = idx

        actual_end_sec = words[best_end_idx].end
        segment_words = words[best_start_idx : best_end_idx + 1]
        segment_text = " ".join(w.word for w in segment_words)

        start_ms = int(round(actual_start_sec * 1000))
        end_ms = int(round(actual_end_sec * 1000))
        return start_ms, end_ms, segment_text
