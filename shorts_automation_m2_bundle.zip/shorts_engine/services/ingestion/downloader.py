"""
Ingestion Service: Downloads video & audio using yt-dlp and extracts metadata.
Implements exponential backoff retry and robust file management.
"""

import os
import time
import logging
import subprocess
from pathlib import Path
from typing import Dict, Any, Optional
import yt_dlp
from shorts_engine.config.settings import settings

logger = logging.getLogger(__name__)


class VideoDownloadResult:
    def __init__(
        self,
        video_id: str,
        title: str,
        duration_sec: int,
        video_path: Path,
        audio_path: Path,
        metadata: Dict[str, Any],
    ):
        self.video_id = video_id
        self.title = title
        self.duration_sec = duration_sec
        self.video_path = video_path
        self.audio_path = audio_path
        self.metadata = metadata

    def __repr__(self) -> str:
        return (
            f"<VideoDownloadResult id={self.video_id} title='{self.title[:30]}' "
            f"duration={self.duration_sec}s>"
        )


class IngestionService:
    def __init__(self, output_dir: Optional[Path] = None, max_retries: int = 3):
        self.output_dir = output_dir or settings.STORAGE_DIR / "downloads"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.max_retries = max_retries

    def get_video_url(self, video_id_or_url: str) -> str:
        if video_id_or_url.startswith("http://") or video_id_or_url.startswith("https://"):
            return video_id_or_url
        return f"https://www.youtube.com/watch?v={video_id_or_url}"

    def extract_video_id(self, video_id_or_url: str) -> str:
        if "v=" in video_id_or_url:
            return video_id_or_url.split("v=")[1].split("&")[0]
        if "youtu.be/" in video_id_or_url:
            return video_id_or_url.split("youtu.be/")[1].split("?")[0]
        return video_id_or_url

    def extract_audio(self, video_path: Path, audio_path: Path) -> Path:
        """Extracts 16kHz mono WAV from video file using FFmpeg for optimal ASR."""
        audio_path.parent.mkdir(parents=True, exist_ok=True)
        cmd = [
            "ffmpeg",
            "-y",
            "-i", str(video_path),
            "-vn",
            "-acodec", "pcm_s16le",
            "-ar", "16000",
            "-ac", "1",
            str(audio_path),
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode != 0:
            logger.error("FFmpeg audio extraction failed: %s", result.stderr)
            raise RuntimeError(f"FFmpeg audio extraction failed: {result.stderr}")
        return audio_path

    def download_video(self, video_id_or_url: str) -> VideoDownloadResult:
        """
        Downloads the video using yt-dlp with retries and extracts a 16kHz WAV track.
        """
        url = self.get_video_url(video_id_or_url)
        video_id = self.extract_video_id(video_id_or_url)
        target_video = self.output_dir / f"{video_id}.mp4"
        target_audio = self.output_dir / f"{video_id}_audio.wav"

        # Check cache if files already exist
        if target_video.exists() and target_video.stat().st_size > 0 and target_audio.exists():
            logger.info("Video %s already downloaded at %s", video_id, target_video)
            meta = self.get_metadata(url)
            return VideoDownloadResult(
                video_id=video_id,
                title=meta.get("title", video_id),
                duration_sec=int(meta.get("duration", 0)),
                video_path=target_video,
                audio_path=target_audio,
                metadata=meta,
            )

        ydl_opts = {
            "format": "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
            "outtmpl": str(self.output_dir / f"{video_id}.%(ext)s"),
            "merge_output_format": "mp4",
            "quiet": True,
            "no_warnings": True,
        }

        last_err = None
        for attempt in range(1, self.max_retries + 1):
            try:
                logger.info("Downloading %s (attempt %d/%d)...", url, attempt, self.max_retries)
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url, download=True)
                    actual_video = Path(ydl.prepare_filename(info))
                    if not actual_video.exists() and target_video.exists():
                        actual_video = target_video

                    # Extract WAV audio for transcription
                    self.extract_audio(actual_video, target_audio)

                    return VideoDownloadResult(
                        video_id=video_id,
                        title=info.get("title", video_id),
                        duration_sec=int(info.get("duration", 0)),
                        video_path=actual_video,
                        audio_path=target_audio,
                        metadata=info,
                    )
            except Exception as e:
                last_err = e
                logger.warning("Attempt %d failed to download %s: %s", attempt, url, str(e))
                time.sleep(2 ** attempt)

        raise RuntimeError(f"Failed to download video {video_id} after {self.max_retries} attempts: {last_err}")

    def get_metadata(self, video_id_or_url: str) -> Dict[str, Any]:
        """Extracts metadata without downloading media."""
        url = self.get_video_url(video_id_or_url)
        with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True}) as ydl:
            return ydl.extract_info(url, download=False)
