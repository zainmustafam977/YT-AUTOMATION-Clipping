"""
Contextual SFX Mapper: maps keywords, rhetorical reveals, and emotional transitions
to audio cue tags (whoosh, pop, ding, reveal, hit) with relative timestamps.
"""

from typing import List, Dict, Any
from shorts_engine.services.transcription.formatter import WordSegment

KEYWORD_SFX_MAP = {
    # High-impact transitions
    "whoosh": ["suddenly", "however", "next", "change", "switch", "turned", "meanwhile"],
    # Revelations / Insights
    "ding": ["secret", "remember", "key", "tip", "rule", "truth", "solution", "hack"],
    # Surprise / Punchlines
    "pop": ["boom", "surprise", "insane", "crazy", "huge", "never", "watch"],
    # Dramatic emphasis
    "reveal": ["actually", "realized", "discovered", "shocking", "unbelievable", "reveal", "revealed"],
}


class SoundCue:
    def __init__(self, tag: str, offset_sec: float, keyword: str):
        self.tag = tag
        self.offset_sec = round(offset_sec, 2)
        self.keyword = keyword

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tag": self.tag,
            "offset_sec": self.offset_sec,
            "keyword": self.keyword,
        }

    def __repr__(self) -> str:
        return f"<SoundCue tag={self.tag} at {self.offset_sec}s for '{self.keyword}'>"


class SFXMapper:
    def map_sfx_cues(
        self,
        words: List[WordSegment],
        segment_start_sec: float,
        min_interval_sec: float = 4.0,
    ) -> List[SoundCue]:
        """
        Maps keywords to SFX cues with interval spacing to avoid audio clutter.
        """
        cues: List[SoundCue] = []
        last_cue_time = -10.0

        for w in words:
            clean_word = w.word.lower().strip(".,!?;:\"'")
            offset = max(0.0, w.start - segment_start_sec)

            # Check interval limit
            if offset - last_cue_time < min_interval_sec:
                continue

            matched_tag = None
            for tag, keywords in KEYWORD_SFX_MAP.items():
                if clean_word in keywords:
                    matched_tag = tag
                    break

            if matched_tag:
                cues.append(SoundCue(tag=matched_tag, offset_sec=offset, keyword=clean_word))
                last_cue_time = offset

        return cues
