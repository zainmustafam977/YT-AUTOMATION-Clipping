"""
Configuration and settings for YouTube Shorts Automation Platform.
Implements unified single source of truth for all pipeline constants.
"""

from pathlib import Path
from typing import Optional
from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class PipelineSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # General App Config
    APP_NAME: str = "YouTube Shorts Automation"
    ENV: str = Field(default="development", description="development, staging, or production")
    DEBUG: bool = False
    
    # Base paths
    ROOT_DIR: Path = Path(__file__).resolve().parent.parent.parent
    STORAGE_DIR: Path = ROOT_DIR / "storage"
    TEMP_DIR: Path = ROOT_DIR / "storage" / "temp"
    OUTPUT_DIR: Path = ROOT_DIR / "storage" / "outputs"
    SFX_DIR: Path = ROOT_DIR / "assets" / "sfx_library"
    MODELS_DIR: Path = ROOT_DIR / "storage" / "models"

    # Database
    DATABASE_URL: str = Field(default="sqlite:///./storage/shorts_automation.db")

    # Security & Encryption (AES-256-GCM)
    MASTER_ENCRYPTION_KEY: str = Field(
        default="yt_shorts_dev_master_secret_key_32_bytes_min!",
        description="Master key used to derive AES-256-GCM key for encrypting OAuth tokens and API secrets",
    )
    ENCRYPTION_SALT: str = Field(
        default="yt_shorts_kdf_salt_2026_secure!",
        description="Salt for PBKDF2 key derivation",
    )

    # LLM Settings (Current Flagship Gemini 3.8 Flash via google-genai)
    LLM_MODEL_NAME: str = Field(
        default="gemini-3.8-flash",
        description="Swappable model identifier (e.g. gemini-3.8-flash, gemini-3-flash)",
    )
    GEMINI_API_KEY: Optional[str] = Field(default=None, description="Google Gemini API Key")

    # Segment Limits (Aligned across selection & reporting)
    MIN_SEGMENTS_PER_VIDEO: int = Field(default=3, ge=1, le=8)
    MAX_SEGMENTS_PER_VIDEO: int = Field(default=5, ge=1, le=8)

    # Duration Boundaries (Unified across AI selection & quality gate)
    TARGET_DURATION_MIN_SEC: int = Field(default=15, ge=5, le=180)
    TARGET_DURATION_MAX_SEC: int = Field(default=58, ge=10, le=180)
    EXTENDED_SHORTS_ALLOWED: bool = False
    MAX_EXTENDED_DURATION_SEC: int = 180

    # Video & Reframing
    TARGET_WIDTH: int = 1080
    TARGET_HEIGHT: int = 1920
    SMOOTHING_FACTOR: float = Field(default=0.85, ge=0.1, le=0.99)
    SAFE_ZONE_MIN_X: float = Field(default=0.15, description="Safe frame margin 15%")
    SAFE_ZONE_MAX_X: float = Field(default=0.85, description="Safe frame margin 85%")

    # Safe Zones & UI Collision Dead Zones (1080x1920 canvas)
    # YouTube Shorts native UI covers bottom 20% (Y > 80% / 1536px, 384px height) and right action bar
    UI_DEADZONE_BOTTOM_Y_RATIO: float = Field(
        default=0.80,
        description="Rejection boundary: bottom 384px (Y > 80% / 1536px) reserved for title/channel UI",
    )
    UI_DEADZONE_RIGHT_X_RATIO: float = Field(
        default=0.85,
        description="Rejection boundary: right 15% (X > 85% / 918px) reserved for like/share/remix buttons",
    )
    CAPTION_MARGIN_VERTICAL: int = Field(
        default=420,
        description="ASS subtitle margin from bottom: 420px (Y = 78.1% / 1500px), providing a 36px buffer above the 384px UI dead zone",
    )

    # Captioning & Typography
    CAPTION_FONT_NAME: str = "Arial Black"
    CAPTION_FONT_SIZE: int = 24
    CAPTION_PRIMARY_COLOR: str = "&H00FFFFFF"  # White
    CAPTION_HIGHLIGHT_COLOR: str = "&H0000FFFF"  # Yellow / Neon
    CAPTION_OUTLINE_COLOR: str = "&H00000000"  # Black
    CAPTION_OUTLINE_WIDTH: int = 3
    ENABLE_LUMINANCE_SAMPLING: bool = True

    # Audio Mastering & Loudness (EBU R128)
    TARGET_LUFS: float = -14.0
    TRUE_PEAK_DBFS: float = -1.0
    MIN_SPEECH_SNR_DB: float = 8.0

    # Publishing & Quotas
    DRY_RUN_PUBLISHING: bool = Field(default=True, description="When true, simulates upload without calling YouTube API")
    DEFAULT_PRIVACY_STATUS: str = Field(default="unlisted", description="unlisted, private, or public")
    DAILY_QUOTA_LIMIT: int = 10000
    QUOTA_WARNING_THRESHOLD: float = 0.80  # Alert when 80% quota is used

    # Detection & WebSub
    RSS_POLL_INTERVAL_MINUTES: int = 10
    WEBSUB_HUB_URL: str = "https://pubsubhubbub.appspot.com/subscribe"
    WEBSUB_LEASE_SECONDS: int = 86400           # 24h default
    WEBSUB_RENEW_THRESHOLD: float = 0.80        # Renew at 80% of lease lifetime
    WEBSUB_CALLBACK_URL: Optional[str] = None
    WEBSUB_SECRET: Optional[str] = None

    # Fault tolerance
    MAX_RETRY_COUNT: int = Field(default=5, ge=1, le=10)

    # Operator Dashboard
    DASHBOARD_HOST: str = "127.0.0.1"
    DASHBOARD_PORT: int = 8080
    DASHBOARD_SECRET_KEY: str = Field(default="change-me-in-prod", description="Session signing key")
    DASHBOARD_USERNAME: str = Field(default="admin", description="HTTP Basic Auth username")
    DASHBOARD_PASSWORD: str = Field(default="change-me", description="HTTP Basic Auth password")

    # Alerting & Notifications
    SLACK_WEBHOOK_URL: Optional[str] = None
    DISCORD_WEBHOOK_URL: Optional[str] = None
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    TELEGRAM_CHAT_ID: Optional[str] = None
    SENTRY_DSN: Optional[str] = None


    @model_validator(mode="after")
    def validate_bounds(self) -> "PipelineSettings":
        if self.MIN_SEGMENTS_PER_VIDEO > self.MAX_SEGMENTS_PER_VIDEO:
            raise ValueError(
                f"MIN_SEGMENTS_PER_VIDEO ({self.MIN_SEGMENTS_PER_VIDEO}) cannot exceed "
                f"MAX_SEGMENTS_PER_VIDEO ({self.MAX_SEGMENTS_PER_VIDEO})"
            )
        if self.TARGET_DURATION_MIN_SEC > self.TARGET_DURATION_MAX_SEC:
            raise ValueError(
                f"TARGET_DURATION_MIN_SEC ({self.TARGET_DURATION_MIN_SEC}) cannot exceed "
                f"TARGET_DURATION_MAX_SEC ({self.TARGET_DURATION_MAX_SEC})"
            )
        # Production & Staging security guard: disallow default credentials & enforce minimum entropy
        if self.ENV in ("staging", "production"):
            insecure_passwords = {"change-me", "admin", "password", "123456", "12345678", "root", ""}
            if self.DASHBOARD_PASSWORD.lower() in insecure_passwords or len(self.DASHBOARD_PASSWORD) < 12:
                raise ValueError(
                    f"Insecure DASHBOARD_PASSWORD for '{self.ENV}' environment. "
                    "Password must not be a common default and must be at least 12 characters long."
                )
            if self.DASHBOARD_SECRET_KEY in ("change-me-in-prod", "") or len(self.DASHBOARD_SECRET_KEY) < 32:
                raise ValueError(
                    f"Insecure DASHBOARD_SECRET_KEY for '{self.ENV}' environment. "
                    "Secret key must not be a default and must be at least 32 characters long."
                )
        # Ensure directories exist
        for directory in [self.STORAGE_DIR, self.TEMP_DIR, self.OUTPUT_DIR, self.SFX_DIR, self.MODELS_DIR]:
            directory.mkdir(parents=True, exist_ok=True)
        return self


# Global singleton settings instance
settings = PipelineSettings()
