"""
Pipeline Orchestrator: executes the end-to-end shorts automation workflow
with idempotency, step resumption, and audit logging.
"""

import json
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from shorts_engine.config.settings import settings
from shorts_engine.db.models import (
    Channel,
    SourceVideo,
    SourceVideoStatus,
    Transcript,
    ClipCandidate,
    Clip,
    ClipStatus,
)
from shorts_engine.services.ingestion.downloader import IngestionService
from shorts_engine.services.transcription.engine import TranscriptionService
from shorts_engine.services.transcription.formatter import FormattedTranscript, WordSegment
from shorts_engine.services.clip_selection.selector import ClipSelectionService, SelectedClip
from shorts_engine.services.reframing.cropper import VideoReframer
from shorts_engine.services.captioning.ass_generator import ASSSubtitleGenerator
from shorts_engine.services.captioning.contrast_sampler import ContrastSampler
from shorts_engine.services.captioning.sfx_mapper import SFXMapper
from shorts_engine.services.rendering.compositor import VideoCompositor
from shorts_engine.services.quality_gate.review_queue import QualityGateManager
from shorts_engine.services.publishing.client import YouTubePublisher
from shorts_engine.services.publishing.metadata import ShortsMetadata
from shorts_engine.services.monitoring.alerter import PipelineAlerter
from shorts_engine.orchestration.lifecycle import LifecycleManager

logger = logging.getLogger(__name__)


class PipelineRunner:
    def __init__(self, db_session: Session):
        self.db = db_session
        self.lifecycle = LifecycleManager(db_session)
        self.ingestion = IngestionService()
        self.transcription = TranscriptionService()
        self.clip_selector = ClipSelectionService()
        self.reframer = VideoReframer()
        self.ass_generator = ASSSubtitleGenerator()
        self.contrast_sampler = ContrastSampler()
        self.sfx_mapper = SFXMapper()
        self.compositor = VideoCompositor()
        self.quality_gate = QualityGateManager()
        self.publisher = YouTubePublisher(db_session)
        self.alerter = PipelineAlerter()

    def get_or_create_channel(self, channel_id_str: str = "default_channel", name: str = "Default Channel") -> Channel:
        channel = self.db.query(Channel).filter_by(youtube_channel_id=channel_id_str).first()
        if not channel:
            channel = Channel(
                youtube_channel_id=channel_id_str,
                name=name,
                watch_enabled=True,
                human_review_required=True,
            )
            self.db.add(channel)
            self.db.commit()
        return channel

    def run_pipeline_for_video(
        self,
        video_id_or_url: str,
        channel: Optional[Channel] = None,
        dry_run: bool = True,
    ) -> Dict[str, Any]:
        """
        Executes the complete pipeline for a video from start to finish.
        Resumes seamlessly if video was previously partially processed.
        """
        if channel is None:
            channel = self.get_or_create_channel()

        video_id = self.ingestion.extract_video_id(video_id_or_url)
        logger.info("Starting pipeline for video ID: %s (dry_run=%s)...", video_id, dry_run)

        # 1. Get or create SourceVideo record
        video = self.db.query(SourceVideo).filter_by(
            channel_id=channel.id, youtube_video_id=video_id
        ).first()

        if not video:
            video = SourceVideo(
                channel_id=channel.id,
                youtube_video_id=video_id,
                title=f"Video {video_id}",
                status=SourceVideoStatus.DETECTED,
                retry_count=0,
            )
            self.db.add(video)
            # Write last_seen_video_id so RSS poller won't re-detect this video on restart
            channel.last_seen_video_id = video_id
            self.db.commit()

        # Step A: Ingestion / Download
        if video.status == SourceVideoStatus.DETECTED:
            self.lifecycle.transition_video(video, SourceVideoStatus.DOWNLOADING)
            try:
                download_res = self.ingestion.download_video(video_id_or_url)
                video.title = download_res.title
                video.duration_sec = download_res.duration_sec
                video.downloaded_path = str(download_res.video_path)
                video.audio_path = str(download_res.audio_path)
                self.lifecycle.transition_video(video, SourceVideoStatus.TRANSCRIBING)
            except Exception as e:
                video.status = SourceVideoStatus.FAILED
                video.error_message = str(e)
                self.db.commit()
                self.alerter.alert("Ingestion Failed", str(e), level="ERROR", context={"video_id": video_id})
                raise

        # Step B: Transcription
        formatted_transcript = None
        if video.status == SourceVideoStatus.TRANSCRIBING:
            transcript_record = self.db.query(Transcript).filter_by(source_video_id=video.id).first()
            if not transcript_record:
                try:
                    formatted_transcript = self.transcription.transcribe(Path(video.audio_path))
                    transcript_record = Transcript(
                        source_video_id=video.id,
                        word_level_json=json.dumps(formatted_transcript.to_dict()),
                        language=formatted_transcript.language,
                    )
                    self.db.add(transcript_record)
                    self.db.commit()
                except Exception as e:
                    video.status = SourceVideoStatus.FAILED
                    video.error_message = str(e)
                    self.db.commit()
                    self.alerter.alert("Transcription Failed", str(e), level="ERROR", context={"video_id": video_id})
                    raise
            self.lifecycle.transition_video(video, SourceVideoStatus.ANALYZING)

        # Load transcript if not in memory
        if formatted_transcript is None:
            transcript_record = self.db.query(Transcript).filter_by(source_video_id=video.id).first()
            if transcript_record:
                data = json.loads(transcript_record.word_level_json)
                formatted_transcript = FormattedTranscript.from_dict(data)

        # Step C: Clip Selection
        candidates: List[ClipCandidate] = self.db.query(ClipCandidate).filter_by(source_video_id=video.id).all()
        if video.status == SourceVideoStatus.ANALYZING and not candidates:
            try:
                selected_clips: List[SelectedClip] = self.clip_selector.select_clips(
                    formatted_transcript,
                    min_clips=settings.MIN_SEGMENTS_PER_VIDEO,
                    max_clips=settings.MAX_SEGMENTS_PER_VIDEO,
                )
                for sc in selected_clips:
                    cand = ClipCandidate(
                        source_video_id=video.id,
                        start_ms=sc.start_ms,
                        end_ms=sc.end_ms,
                        score=sc.score,
                        reason=sc.reason,
                        hook_text=sc.hook_text,
                        payoff_text=sc.payoff_text,
                        selected=True,
                    )
                    self.db.add(cand)
                self.db.commit()
                candidates = self.db.query(ClipCandidate).filter_by(source_video_id=video.id).all()
                self.lifecycle.transition_video(video, SourceVideoStatus.SEGMENTS_SELECTED)
            except Exception as e:
                video.status = SourceVideoStatus.FAILED
                video.error_message = str(e)
                self.db.commit()
                self.alerter.alert("Clip Selection Failed", str(e), level="ERROR", context={"video_id": video_id})
                raise

        # Step D: Process Each Selected Candidate
        processed_clips = []
        for cand in candidates:
            clip = self.db.query(Clip).filter_by(clip_candidate_id=cand.id).first()
            if not clip:
                clip = Clip(
                    clip_candidate_id=cand.id,
                    status=ClipStatus.RENDERING,
                )
                self.db.add(clip)
                self.db.commit()

            # D1: Reframing, Captioning & Rendering
            if clip.status == ClipStatus.RENDERING:
                try:
                    # Reframing crop plan
                    crop_plan = self.reframer.compute_crop_plan(
                        Path(video.downloaded_path),
                        start_ms=cand.start_ms,
                        end_ms=cand.end_ms,
                    )

                    # Subtitles
                    sub_path = settings.TEMP_DIR / f"{video_id}_{cand.start_ms}.ass"
                    self.ass_generator.generate_ass(
                        words=formatted_transcript.words,
                        segment_start_ms=cand.start_ms,
                        segment_end_ms=cand.end_ms,
                        output_path=sub_path,
                    )

                    # SFX mapping
                    sfx_cues = self.sfx_mapper.map_sfx_cues(
                        formatted_transcript.words,
                        segment_start_sec=cand.start_ms / 1000.0,
                    )
                    clip.sfx_tags_json = json.dumps([c.to_dict() for c in sfx_cues])

                    # Render
                    out_name = f"{video_id}_short_{cand.start_ms}.mp4"
                    rendered_file = self.compositor.render_short(
                        source_video_path=Path(video.downloaded_path),
                        start_ms=cand.start_ms,
                        end_ms=cand.end_ms,
                        crop_plan=crop_plan,
                        subtitle_ass_path=sub_path,
                        output_filename=out_name,
                        normalize_audio=True,
                    )
                    clip.rendered_path = str(rendered_file)
                    clip.status = ClipStatus.QUALITY_CHECK
                    self.db.commit()
                except Exception as e:
                    clip.status = ClipStatus.FAILED
                    self.db.commit()
                    self.alerter.alert("Rendering Failed", str(e), level="ERROR", context={"clip_id": clip.id})
                    continue

            # D2: Two-Tier Quality Gate
            if clip.status == ClipStatus.QUALITY_CHECK:
                new_status, q_report = self.quality_gate.evaluate_clip(
                    rendered_video_path=Path(clip.rendered_path),
                    segment_text=cand.hook_text or "",
                    hook_text=cand.hook_text or "",
                    payoff_text=cand.payoff_text or "",
                    human_review_required=channel.human_review_required,
                )
                clip.status = new_status
                clip.quality_check_result = json.dumps(q_report)
                self.db.commit()

            # D3: Publishing (if APPROVED)
            if clip.status == ClipStatus.APPROVED:
                meta = ShortsMetadata(
                    title=f"{video.title[:50]} Highlight",
                    description=f"{video.title} - best moment.\n\n#Shorts #Viral #Highlights",
                    tags=["#shorts", "#viral", "#highlights"],
                )
                pub_res = self.publisher.publish_clip(clip, meta, dry_run=dry_run)
                processed_clips.append(pub_res)
            else:
                processed_clips.append({
                    "clip_id": clip.id,
                    "status": clip.status.value,
                    "rendered_path": clip.rendered_path,
                })

        video.status = SourceVideoStatus.DONE
        self.db.commit()

        return {
            "source_video_id": video.id,
            "youtube_video_id": video.youtube_video_id,
            "title": video.title,
            "status": video.status.value,
            "clips_count": len(candidates),
            "clips": processed_clips,
        }
