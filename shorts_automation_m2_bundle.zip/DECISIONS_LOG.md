# YouTube Shorts Automation Platform — Running Decisions Log & Technical Standard

> **AUTHORITY STATEMENT:**  
> This document is the single, authoritative, running record of all architectural, operational, and technical decisions for the YouTube Shorts Automation project. Every PR, code change, configuration update, and documentation artifact **must be verified against this file** to prevent regression, contradictory guidance, or mismatched naming.

---

## 1. Active Technical Standards & Model Selections

| Area | Decision | Details & Implementation | Rationale / History |
|---|---|---|---|
| **LLM Provider** | **Gemini 3.8 Flash** | `LLM_MODEL_NAME = "gemini-3.8-flash"` in `shorts_engine/config/settings.py`. Uses `google-genai` SDK with `CandidateSegmentsResponse` structured output schema. | Gemini 1.5 Flash and 2.0 Flash were officially retired on June 1, 2026. Swappable via `settings.LLM_MODEL_NAME`. |
| **Video Format** | **1080x1920 (9:16 portrait)** | Target resolution 1080x1920. YouTube Shorts duration: 15–58s default (max 180s allowed if extended flag enabled). Single source of truth in `settings.py`. | R2-01 resolved: clip selection and quality gate read from same duration constants. |
| **Safe Margins & UI Collision Boundaries** | **Placement: 420px baseline (Y = 78.1%)<br>Rejection: Y > 80% (bottom 384px)** | • `CAPTION_MARGIN_VERTICAL = 420` in `settings.py` sets ASS subtitle baseline 420px from bottom (`Y = 1500px` on a `1920px` canvas, or `78.1%`).<br>• `UI_DEADZONE_BOTTOM_Y_RATIO = 0.80` in `settings.py` defines the YouTube native title/channel overlay zone (`Y > 1536px`, bottom `384px`).<br>• The 420px placement baseline provides an intentional **36px protective buffer** above the 384px UI dead zone to guarantee multi-line stacks and tall font ascenders never clip into native YouTube overlays.<br>• `render_inspector.py` inspects both the bottom dead zone (`Y > 80%`) and right-side button zone (`X > 85%`) using Canny edge density to reject any render with text bleed. | Arithmetically reconciled across `ass_generator.py` and `render_inspector.py`. Single source of truth in `settings.py`. |
| **Face & Subject Tracking** | **OpenCV YuNet ONNX** | `cv2.FaceDetectorYN` with dynamic model download (`face_detection_yunet_2023mar.onnx`). Haar cascades explicitly dropped. | M-05 resolved: YuNet provides high accuracy across lighting/angle variations without heavy PyTorch model deps. |
| **Audio Loudness** | **EBU R128 normalization** | Compositor applies FFmpeg `loudnorm=I=-14:TP=-1.0:LRA=11`. Target: `-14.0 LUFS`, `-1.0 dBFS` true peak. | Complies with YouTube loudness standards; prevents clipping and distortion across mobile speakers. |
| **Transcription** | **faster-whisper + Forced Alignment** | `faster-whisper` (auto GPU/CPU) with VAD filter + `ForcedAligner` ensuring monotonic timestamps and overlap correction (±50ms bound). | M-03 resolved: eliminates timestamp drift and prevents cutting mid-word or mid-breath. |
| **RSS Polling** | **Python stdlib only** | `xml.etree.ElementTree` + `urllib.request`. Zero external dependencies (no `feedparser`). | Lightweight, robust, eliminates dependency conflicts. |

---

## 2. Security, Encryption & Key Rotation Standards

| Area | Decision | Details & Implementation | Rationale / History |
|---|---|---|---|
| **Encryption Algorithm** | **AES-256-GCM** | Authenticated AES-256-GCM with PBKDF2-HMAC-SHA256 (600,000 iterations). 16-byte random salt + 12-byte nonce prepended to payload: `[salt][nonce][ciphertext+16-byte auth tag]`. | C-02 & R2-02 resolved: Fernet (fixed to AES-128) explicitly rejected in favor of AES-256. |
| **Single-Value Key Rotation** | `rotate_secret()` | Canonical signature in `shorts_engine/db/security.py`:<br>`rotate_secret(encrypted_b64: str, old_master_key: str, new_master_key: str) -> str` | Decrypts under old key, re-encrypts under new key for an individual value. |
| **Bulk Key Rotation** | `rotate_all_channel_tokens()` | In `shorts_engine/db/security.py`:<br>`rotate_all_channel_tokens(db: Session, old_master_key: str, new_master_key: str) -> int`<br>Wrapped in a **single atomic transaction** with full rollback on any failure. | Delivers full database-wide secret rotation in a single operation. |
| **CLI Rotation Command** | `python run.py rotate-secrets` | CLI command: `python run.py rotate-secrets --old-key <OLD> --new-key <NEW>` | Allows operators to rotate encryption keys during credential rotation runbooks. |
| **Dashboard Transport Security** | **TLS / HTTPS Termination at Ingress** | Uvicorn / FastAPI must NEVER be exposed directly to the public internet on unencrypted HTTP.<br>• Local Dev: Bound to `127.0.0.1:8080` (use TLS tunnels like `cloudflared` or `ngrok` for testing public WebSub callbacks).<br>• Staging & Production: Terminated at ingress / reverse proxy (Caddy, Nginx, or AWS ALB / GCP Cloud Load Balancer) with automated Let's Encrypt certificates, HTTP-to-HTTPS redirect, and HSTS headers. Internal communication to uvicorn is over localhost or private container networks. | Prevents Basic Auth base64 credential sniffing and secures operator review/approve actions over the wire. |
| **Credential Rotation Enforcement** | **Automated Startup Gate** | `settings.py` model validator strictly raises `ValueError` if `ENV in ('staging', 'production')` and `DASHBOARD_PASSWORD` equals `change-me`, `admin`, `password`, or empty, or if `DASHBOARD_SECRET_KEY` equals `change-me-in-prod`.<br>Deployment pipelines (Milestone 3) inject real credentials via platform secret managers (AWS Secrets Manager, GCP Secret Manager, or GitHub Actions secrets). | Eliminates human error by programmatically preventing staging/production instances from booting with default credentials. |
| **Secret Masking** | `mask_secret()` | Shows first/last 4 characters, redacts intermediate characters with `...` for safe audit logging. | Prevents secret leakage in error reports and logs. |

---

## 3. Delivery Phasing & Architectural Scope Boundaries

| Milestone | Scope Included | Scope Deferred / Excluded |
|---|---|---|
| **Milestone 1**<br>*(Phase 0 MVP — Completed & Accepted)* | • Ingestion (`yt-dlp` with backoff)<br>• Transcription (`faster-whisper` + forced alignment)<br>• Clip Selection (Gemini 3.8 Flash + boundary snapper)<br>• 9:16 Reframing (YuNet ONNX + active speaker)<br>• Captions & SFX (ASS karaoke + luminance sampler)<br>• Rendering (FFmpeg EBU R128 compositing)<br>• Quality Gate (Technical + Multimodal Inspector + Semantic)<br>• Publishing (`DRY_RUN_PUBLISHING=True` default)<br>• 30 acceptance & regression tests | • Unattended WebSub detection<br>• Real OAuth2 upload network calls<br>• Operator dashboard UI<br>• Multi-user auth |
| **Milestone 2**<br>*(Phase 1 Automate Loop — Active)* | • Detection Service: WebSub push subscriber with HMAC-SHA1 verification + 80% lease renewal manager<br>• Detection Service: RSS fallback poller updating `last_seen_video_id`<br>• Real YouTube Data API v3 publisher with OAuth2 decryption<br>• Multi-channel alerting: Slack, Discord, Telegram bot, and Sentry (with startup initialization in `run.py`)<br>• Operator Dashboard (FastAPI): Status page, review queue, dead-letter view, channel manager<br>• **Dashboard Auth: HTTP Basic Auth** (`DASHBOARD_USERNAME` / `DASHBOARD_PASSWORD`)<br>• Dead-letter fault tolerance: `retry_count` + `MAX_RETRY_COUNT=5` ceiling with retry endpoint<br>• 15 new tests covering M2 additions | • Session-based multi-user RBAC<br>• PostgreSQL production migration<br>• GPU autoscaling<br>• Title A/B testing feedback loops |
| **Milestone 3**<br>*(Phase 2 Scale & Infrastructure)* | • PostgreSQL migration (triggered by multi-worker/Docker Compose deployment)<br>• Full session-based operator auth & multi-user RBAC<br>• GPU worker autoscaling (cloud VM / rented GPU orchestrator)<br>• Expanded commercial SFX library<br>• Phase 3 Title A/B testing and rubric refinement loop | — |

---

## 4. State Machine & Data Model Invariants

| Invariant | Specification | Location |
|---|---|---|
| **Distinct Review States** | `ClipStatus.QUALITY_CHECK` and `ClipStatus.WAITING_APPROVAL` are **distinct enum values**. `QUALITY_CHECK` is an automated processing state; `WAITING_APPROVAL` is the human review queue state. | `shorts_engine/db/models.py` |
| **Unique Constraints** | • `SourceVideo`: `UniqueConstraint("channel_id", "youtube_video_id")`<br>• `PublishLog`: `UniqueConstraint("clip_id", "youtube_video_id")` | `shorts_engine/db/models.py` |
| **Atomic State Locking** | Transitions must go through `LifecycleManager.transition_video()` / `transition_clip()` with optional `expected_status` lock verification. | `shorts_engine/orchestration/lifecycle.py` |
| **Last Seen Video Tracking** | `channel.last_seen_video_id` must be written immediately when a new video is detected in both `RSSPoller` and `PipelineRunner`. | `shorts_engine/services/detection/rss_poller.py`<br>`shorts_engine/orchestration/runner.py` |
| **Dead-Letter Ceiling** | `retry_count` is tracked on `SourceVideo` and `Clip`. If `retry_count >= MAX_RETRY_COUNT` (default 5), retry is blocked and manual intervention is required. | `shorts_engine/db/models.py`<br>`shorts_engine/dashboard/routes/queue.py` |
| **Channel OAuth Credential Storage** | `Channel.encrypted_oauth_token` (`Text`, nullable). Holds the AES-256-GCM encrypted refresh token payload (`[16B salt][12B nonce][ciphertext+16B auth tag]`). Never exposed in plaintext; only decrypted in memory at the moment of upload in `YouTubePublisher`. Bulk rotation orchestrated via `rotate_all_channel_tokens()`. | `shorts_engine/db/models.py`<br>`shorts_engine/db/security.py` |
| **Quota Protection** | `YouTubePublisher` verifies quota before attempting upload. On quota exhaustion, returns `{"quota_exhausted": True}` without mutating status to `FAILED`, preserving clip in `APPROVED` for retry. | `shorts_engine/services/publishing/client.py` |

---

## 5. Changelog & Resolution History

- **2026-09-10 (Round 1 Review):** Addressed 16 items (C-01 to N-02, Q-01). Established 3-milestone delivery phasing.
- **2026-09-10 (Round 2 Review):** Closed 7 items (R2-01 to R2-04, N-01, M-08, C-04). Standardized on `gemini-3.8-flash` and AES-256-GCM.
- **2026-09-10 (Milestone 1 Accepted):** Verified all 30 acceptance and unit tests live. Updated all documentation references.
- **2026-09-10 (Milestone 2 Planning):** Identified and resolved 9 self-review issues (WebSub HTTP webhook receiver, timing-safe HMAC-SHA1, last_seen_video_id gap, Sentry startup init, stdlib XML RSS, deduplicated tests).
- **2026-09-11 (Milestone 2 Refinements):**
  - **Bulk secret rotation:** Confirmed `rotate_secret` as per-value primitive and added `rotate_all_channel_tokens` for atomic database-wide rotation in a single transaction with rollback. Added `python run.py rotate-secrets` CLI command.
  - **Dashboard auth:** Added HTTP Basic Auth (`verify_basic_auth`) on all operator dashboard routes; full session-based RBAC remains scoped to M3.
  - **Decisions log:** Created this centralized `DECISIONS_LOG.md` as the definitive repository reference.
  - **Safe-zone arithmetic reconciliation:** Reconciled ASS subtitle placement baseline (`CAPTION_MARGIN_VERTICAL = 420px`, `Y = 78.1%`) with the UI dead zone rejection boundary (`UI_DEADZONE_BOTTOM_Y_RATIO = 0.80`, bottom `384px`), explicitly documenting the intentional 36px safety buffer. Centralized both constants in `settings.py`.
  - **Schema documentation:** Formally documented `Channel.encrypted_oauth_token` column across `DECISIONS_LOG.md` and `spec_extracted.md` Section 10.1.
  - **Export fidelity standard:** Mandated strict exclusion of LaTeX math delimiters (`$`) in all client write-ups and documentation to prevent dual-layer MathML clipboard/export text corruption.
  - **Transport security & credential gate:** Mandated TLS/HTTPS termination at ingress for staging/production. Added automated startup model validator in `settings.py` (and test in `test_config_consistency.py`) that strictly rejects default credentials (`admin`/`change-me`) in staging or production.

---

## 6. Client Documentation & Export Fidelity Standard

To prevent text corruption when markdown is converted, exported, or copied across client tools (e.g. Word/PDF/plain text):
1. **Zero LaTeX Math Delimiters (`$`) for Simple Values:** Numerical values, dimensions, screen percentages, and coordinates must NEVER use `$...$` syntax. Always format as clean markdown with backticks (e.g. `80%`, `1080x1920`, `1536px`, `384px`, `Y > 0.80`).
2. **Literal Code and Path Formatting:** File paths, test node IDs, and command strings must be written using standard backticks without escaped backslashes (`tests/test_file.py::test_name`).
3. **Verbatim Test Logs:** Test output must always be written directly to a committed, unedited log file (`test_run_output.txt`) rather than manually summarized or reconstructed in chat messages.
