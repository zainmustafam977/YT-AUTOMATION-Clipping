"""
Tests verifying single-source-of-truth configuration consistency (R2-01 & F-03).
"""

import pytest
from pydantic import ValidationError
from shorts_engine.config.settings import PipelineSettings


def test_segment_bounds_enforced():
    settings = PipelineSettings()
    assert settings.MIN_SEGMENTS_PER_VIDEO == 3
    assert settings.MAX_SEGMENTS_PER_VIDEO == 5
    assert settings.TARGET_DURATION_MIN_SEC == 15
    assert settings.TARGET_DURATION_MAX_SEC == 58


def test_segment_upper_bound_constraint():
    # Attempting to configure > 8 segments must fail validation per F-03
    with pytest.raises(ValidationError):
        PipelineSettings(MAX_SEGMENTS_PER_VIDEO=9)


def test_min_greater_than_max_fails():
    with pytest.raises(ValidationError):
        PipelineSettings(MIN_SEGMENTS_PER_VIDEO=6, MAX_SEGMENTS_PER_VIDEO=4)

    with pytest.raises(ValidationError):
        PipelineSettings(TARGET_DURATION_MIN_SEC=70, TARGET_DURATION_MAX_SEC=50)


def test_production_default_password_rejected():
    # Production refuses to boot with default credentials
    with pytest.raises(ValidationError, match="Insecure DASHBOARD_PASSWORD"):
        PipelineSettings(ENV="production", DASHBOARD_PASSWORD="change-me")

    # Production also rejects short/weak passwords (e.g. "1234")
    with pytest.raises(ValidationError, match="Insecure DASHBOARD_PASSWORD"):
        PipelineSettings(ENV="production", DASHBOARD_PASSWORD="1234")

    # Production rejects default or short session secret key (< 32 chars)
    with pytest.raises(ValidationError, match="Insecure DASHBOARD_SECRET_KEY"):
        PipelineSettings(
            ENV="production",
            DASHBOARD_PASSWORD="strong_random_pass_123!",
            DASHBOARD_SECRET_KEY="change-me-in-prod",
        )

    # Production succeeds with real non-default credentials (>=12 char password, >=32 char secret)
    prod_settings = PipelineSettings(
        ENV="production",
        DASHBOARD_PASSWORD="strong_random_pass_123!",
        DASHBOARD_SECRET_KEY="cryptographically_secure_random_key_abc_12345",
    )
    assert prod_settings.DASHBOARD_PASSWORD == "strong_random_pass_123!"
